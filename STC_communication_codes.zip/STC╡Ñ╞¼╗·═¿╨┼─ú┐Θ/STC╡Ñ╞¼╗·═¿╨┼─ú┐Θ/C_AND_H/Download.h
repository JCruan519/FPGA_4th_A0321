#ifndef Download
#define Download
#define FOSC 24000000L
#define BAUD 9600

/*
//ϵͳʱ��
#define FOSC 33177600L
#define FOSC 30000000L
#define FOSC 24000000L
#define FOSC 22118400L
#define FOSC 11059200L 

//���ڲ�����

#define BAUD   9600
#define BAUD  14400
#define BAUD  19200
#define BAUD  28800
#define BAUD  38400
#define BAUD 115200  

*/
/*
�����ͺ�
STC15W408AS  28800
STC15W1K16S  28800
STC15W4K32S4 19200
STC8 F2K16S2 38400


*/
#endif